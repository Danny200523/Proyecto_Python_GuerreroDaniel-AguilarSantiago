def MenuPrincipal():
    print('''
==============================
=  Bienvenido a Campuslands  =
==============================
=       ¿Quien eres?         =
==============================
=     (1). Camper            =
=     (2). Trainer           =
=     (3). Cordinadora       =
==============================
          ''')
    
def MenuCamper():
    print('''
==============================
=     ¿Estas Inscrito?       =
==============================
=          (1).SI            =
=          (2).NO            =
==============================
          ''')

def MenuInscripcionCamper():
    print('''
==============================
=        Bienvenido          =
==============================
          ''')
    

def SiInscrito():
    print('''
============================
=    Bienvenido, Camper    =
============================
          ''')#Funcion para pedir al camper su ID y acceder a sus datos.
    
def LogTrainer():
    print('''
 ==========================
 =  Bienvenido, Trainer   =
 ==========================
          ''') # Validar usuario (Opcional para mejorar el programa) 

def MenuTrainer():
    print('''
==========================
=   ¿Qué deseas hacer?   =
==========================
=   1. Ver notas         =
=   2. Editar notas      =
=   3. Ver estudiantes   =
==========================
          ''')
    
def Menucordinadora():
    print('''
=========================================
=          ¿Que desea hacer?            =
=========================================
=   (1).Agregar estudiante              =
=   (2).Editar estudiante               =
=   (3).Ver estudiantes                 =
=   (4).Eliminar estudiante             =
=   (5).Agregar estudiante a curso      =
=   (6).Agregar nueva ruta de estudio   =
=   (7).Asignar ruta a trainer          =
=========================================
          ''')
    
