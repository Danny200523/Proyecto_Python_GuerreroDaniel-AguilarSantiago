import json
from Logic.Coordinadora import *
from Design.Menus import *
camp=abrirJSON()
list=[]
bo=True
while bo==True:
    for i in range(len(camp["Campers"])):
        if camp["Campers"][i]["Estado"]["Cursando"]==True:
            list.append({"nombre":camp["Campers"][i]["nombre"],
                        "Estado":True})
    if len(list)<396:
        asignargrupo()
    MenuPrincipal()
    n=int(input(": "))
    if n==3:
        Menucordinadora()
        opc=int(input(": "))
        if opc==1:
            Aggcamper()
        elif opc==2:
            Editarcamper()
        elif opc==3:
            Vercamper()
        elif opc==4:
            Eliminarcamper()
        elif opc==5:
            Aggcampercurso()
    elif n==2:
        LogTrainer()
        MenuTrainer()
        opc=int(input(": "))
    elif n==1:
        MenuCamper()
        opc=int(input(": "))
        if opc==1:
            SiInscrito()
        elif opc==2:
            MenuInscripcionCamper()
    